=== EZ Shortcode Content (EZSC) ===
Contributors: nonelin
Tags: Shortcode, plugin, wordpress
Donate link: https://dafatime.idv.tw
Requires at least: 6.0
Tested up to: 6.3.2
Requires PHP: 8.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

EZ Shortcode Content, referred to as "EZSC", use EZSC to create short code content and insert it into the article content to display customized content. Add the start and end time to the short code to achieve the function of regularly displaying hidden content.If no time is entered, it will always be displayed.

== Description ==
EZ Shortcode Content, referred to as "EZSC", use EZSC to create short code content and insert it into the article content to display customized content. Add the start and end time to the short code to achieve the function of regularly displaying hidden content.If no time is entered, it will always be displayed.

== Installation ==
1. Upload "ez-shortcode-content" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Create "Shortcode Content" content.
4. Go to posts insert Shortcode. e.g. [ez_shortcode post_id="444" start_time="2023-11-13 12:00" end_time="2023-11-30 12:00"]
*[ez_shortcode post_id="[Shortcode ID]" start_time="[datetime]" end_time="[datetime]"]

== Screenshots ==
1. Shortcode content list to screenshot-1.
2. Shortcode content edit to screenshot-2.
3. Shortcode content TinyMCE editor button insert to screenshot-3.

== Changelog ==
= 0.2 =
* add gutenberg insert Shortcode button .

= 0.1 =
* Initial release.